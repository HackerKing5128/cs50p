#setup.py 

from setuptools import setup

setup(name = "numb3rs", version = "1.0", description = "Validation Tool for IPv4 Adresses", author = "HackerKing5128", py_modules = ["numb3rs"], )
